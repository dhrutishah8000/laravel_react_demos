import { useState } from "react";
import { Container, Form, Button } from "react-bootstrap";
import axios from "axios";


const Login = () => {

    const [email, setEmail] = useState("");
    const [pswd, setPswd] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(email, " | ",pswd);
        axios({
            method : 'post',
            url : "http://127.0.0.1:8000/api/custom-login",
            data : {
                email : email,
                password : pswd
            }
        }).then((response) => {
            console.log("response == ", response);
            if(response.status === 200) {
                console.log('sihnIn success');
                localStorage.setItem("userData", JSON.stringify(response.data));
            }
        }).catch((err) => {
            console.log("Error == ", err);
        })
    }

    const handleChange = (e) => {
        const { name, value } = e.target;
        if(name == "email") {
            setEmail(value);
        }
        if(name == "password") {
            setPswd(value);
        }
    }

    const handleLogout = () => {
        axios({
            method : 'get',
            url : "http://127.0.0.1:8000/api/signout"
        }).then((response) => {
            console.log('Response == ',response);
            localStorage.clear();
        }).catch((err) => {
            console.log(err);
        })
    }

    return(<>
        <Container>
             <h3>Sign In</h3>
             <button type="button" onClick={handleLogout}>Logout</button>
             <Form onSubmit={handleSubmit}>
             <Form.Group className="mb-3" controlId="formBasicEmail">
                 <Form.Label>Email address</Form.Label>
                 <Form.Control type="email" placeholder="Enter email" name="email" onChange={handleChange}/>
                 <Form.Text className="text-muted">
                     We'll never share your email with anyone else.
                 </Form.Text>
             </Form.Group> 
             <Form.Group className="mb-3" controlId="formBasicPassword">
                 <Form.Label>Password</Form.Label>
                 <Form.Control type="password" placeholder="Password" name="password" onChange={handleChange} />
             </Form.Group>
             <Form.Group className="mb-3" controlId="formBasicCheckbox">
                 <Form.Check type="checkbox" label="Check me out" />
             </Form.Group>
             <Button variant="primary" type="submit">
                 Sign In
             </Button>
             </Form>
        </Container>
     </>)
}

export default Login;