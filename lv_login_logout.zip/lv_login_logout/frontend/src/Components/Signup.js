import { useState } from "react";
import { Container, Form, Button } from "react-bootstrap";
import axios from "axios";

const Signup = () => {

    const [name,setName] = useState("");
    const[email,setEmail] = useState("");
    const[pswd,setPswd] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(name , " | ", email , " | ", pswd);
        axios({
            method : "post",
            url : "http://127.0.0.1:8000/api/custom-registration",
            data : {
                name : name,
                email : email,
                password : pswd
            }
        }).then((response) => {
            console.log("Response === ",response);
        }).catch((err) => {
            console.log("Error === ",err);
        })
    }

    const handleChange = (e) => {
        const { name, value } = e.target;
        if(name === 'name') {
            setName(value);
        }
        if(name === 'email') {
            setEmail(value);
        }
        if(name === 'password') {
            setPswd(value);
        }
    }

    return(<>
       <Container>
            <h3>Create an account</h3>
            <Form onSubmit={handleSubmit}>
            <Form.Group className="mb-3" controlId="formBasicName">
                <Form.Label>Name</Form.Label>
                <Form.Control type="text" placeholder="Enter name" name="name" onChange={handleChange} />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Label>Email address</Form.Label>
                <Form.Control type="email" placeholder="Enter email" name="email" onChange={handleChange} />
                <Form.Text className="text-muted">
                    We'll never share your email with anyone else.
                </Form.Text>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Label>Password</Form.Label>
                <Form.Control type="password" placeholder="Password" name="password" onChange={handleChange} />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicCheckbox">
                <Form.Check type="checkbox" label="Check me out" />
            </Form.Group>
            <Button variant="primary" type="submit">
                Sign Up
            </Button>
            </Form>
       </Container>
    </>)
}

export default Signup;