<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Article;

class ArticleController extends Controller
{
    //
    public function index() {
        return Article::all();
    }

    public function create() {
        $input = request()->all();
        $data['title'] = $input['articleName'];
        $data['description'] = $input['articleDesc'];
        $data['author'] = $input['articleAuthor'];
    
        return Article::create($data);
    }

    public function edit($id) {
        return Article::find($id);
    }

    public function update($id) {
        $article = Article::find($id);
        $input = request()->all();
        $data['title'] = $input['articleName'];
        $data['description'] = $input['articleDesc'];
        $data['author'] = $input['articleAuthor'];
        return $article->update($data);
    }

    public function delete($id) {
        return Article::destroy($id);
    }

}
