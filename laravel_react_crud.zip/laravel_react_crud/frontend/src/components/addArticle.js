import axios from "axios";
import { useEffect, useState } from "react";
import { Form, Button, Container } from "react-bootstrap";
import { Link, useNavigate, useParams } from "react-router-dom";

const AddArticle = () => {

    const navigate = useNavigate();
    const { id } = useParams();
    const [articleName, setArticleName] = useState('');
    const [articleDesc, setArticleDesc] = useState('');
    const [articleAuthor, setArticleAuthor] = useState('');

    const submitForm = async (e) => {
        e.preventDefault();
        const articleData = {
            articleName : articleName,
            articleDesc : articleDesc,
            articleAuthor : articleAuthor
        }
        
        let murl = "http://127.0.0.1:8000/api/add";
        if(id){
            murl = "http://127.0.0.1:8000/api/update/"+id;
        }

        const options = {
            method: 'POST',
            data: articleData,
            url: murl
        }

        await axios(options).then((response) => {
            if(response.status == 201) {
                navigate("/");
            }
            
            if(response.status == 200) {
                navigate("/");
            }

        }).catch((err) => {
            console.log("Error === ", err);
        });

    }

    const handleChange = (e) => {
        const { name, value } = e.target;
        if(name == 'aname') {
            setArticleName(value);
        }
        if(name == 'adesc') {
            setArticleDesc(value);
        }
        if(name == 'aauthor') {
            setArticleAuthor(value);
        }
    }

    const getArticle = async (id) => {
        await axios({
            method : 'get',
            url : 'http://127.0.0.1:8000/api/edit/'+id
        }).then((response) => {
            if(response.status === 200) {
                setArticleName(response.data.title);
                setArticleDesc(response.data.description);
                setArticleAuthor(response.data.author);
            }
        }).catch((err) => {
            console.log("Error === ",err);
        });
    }

    useEffect(() => {
        if(id) {
            getArticle(id);
        }
    },[id]);

    return(<>
        <Container>
        <p>Add Form</p>
        <Link to="/">Home</Link>
        <div>
            <Form onSubmit={submitForm}>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Name</Form.Label>
                    <Form.Control type="text" placeholder="Enter name" name="aname" onChange={handleChange} value={articleName}/>
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicPassword">
                    <Form.Label>Description</Form.Label>
                    <Form.Control as="textarea" placeholder="Leave a comment here" name="adesc" onChange={handleChange} value={articleDesc} /> 
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Author Name</Form.Label>
                    <Form.Control type="text" placeholder="Author name" name="aauthor" onChange={handleChange} value={articleAuthor} />
                </Form.Group>
                <Button variant="primary" type="submit" >
                    Submit
                </Button>
            </Form>
        </div>
        </Container>
    </>)
}

export default AddArticle;