import Button from 'react-bootstrap/Button';
import Table from 'react-bootstrap/Table';
import axios from 'axios';
import { useEffect, useState } from 'react';
import { useNavigate, Link } from "react-router-dom";
import Container from 'react-bootstrap/esm/Container';

function Article() {

    const navigate = useNavigate();
    const [aticles, articleList] = useState([]);

    const getArticleData = () => {
        axios({
            method : 'get',
            url : 'http://127.0.0.1:8000/api/articles'

        }).then((response) => {
            if(response.status == 200) {
                articleList(response.data);
            }
        }).catch((err) => {
            console.log("Error ... ",err);
        });
    };

    const addNewArticle = (e) => {
        e.preventDefault();
        navigate("/add");
    }

    const handleDeleteChange = (val) => {
        axios({
            method : 'delete',
            url : 'http://127.0.0.1:8000/api/delete/'+val.id
        }).then((response) => {
            if(response.status == 200) {
                getArticleData();
            }
        }).catch((err) => {
            console.log("Error ==== ",err);
        })
    }

    useEffect(() => {
        getArticleData();        
    },[]);


    return(<>
        <Container>
        <h2 className='center-text'>Article List</h2>
        <Button className="right-button" variant="primary" onClick={addNewArticle}>Add new Article</Button>
        <Table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Article Name</th>
                    <th>Description</th>
                    <th>Author</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                {
                    aticles.map((val,key) => {
                        return(<tr key={key}>
                            <td> {key + 1}</td>
                            <td>{val.title}</td>
                            <td>{val.description.slice(0,15)+"..."}</td>
                            <td>{val.author}</td>
                            <td> 
                                <Link className="w-full" to={`/edit/${val.id}`}>
                                    <Button variant="primary">Edit</Button>
                                </Link>
                                <Button variant='danger' onClick={() => handleDeleteChange(val)}> Delete </Button>
                            </td>
                            </tr>)
                    })
                }
            </tbody>
        </Table>
        </Container>
        
        
    </>)
}

export default Article;