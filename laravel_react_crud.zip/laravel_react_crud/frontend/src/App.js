import { 
  BrowserRouter as Router, 
  Route, 
  Routes 
} from 'react-router-dom'; 

import Container from 'react-bootstrap/Container';
import  Article  from './components/article';
import AddArticle from './components/addArticle';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';

function App() {
  return (
    <Router>
        <Routes>
          <Route path="/" element={<Article />}></Route>
          <Route path="/add" element={<AddArticle />}></Route>
          <Route path="/edit/:id" element={<AddArticle />}></Route>
        </Routes>
        
    </Router>
  );
}

export default App;
